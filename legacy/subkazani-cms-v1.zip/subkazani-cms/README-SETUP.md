# subkazani CMS - نسخه اولیه

این بسته برای تبدیل سایت استاتیک subkazani به یک سایت قابل مدیریت ساخته شده است، بدون تغییر طراحی فعلی.

## معماری

- `site/` = فایل‌هایی که روی GitHub Pages قرار می‌گیرند.
- `site/index.html` = همان ظاهر فعلی، ولی محتوا را از `site/data/content.json` می‌خواند.
- `site/data/content.json` = داده‌های آهنگ‌ها و متن‌ها.
- `admin/` = پنل PHP که باید روی یک هاست دارای PHP قرار بگیرد؛ GitHub Pages PHP اجرا نمی‌کند.
- پنل از GitHub Contents API برای خواندن/نوشتن Repository استفاده می‌کند.

## نکته مهم

فایل‌های فعلی Repository (`avatar.jpg`, `back.jpg`, چهار MP3 و CNAME) باید از Repository فعلی به پوشه `site/` منتقل/کپی شوند. این بسته عمداً فایل صوتی واقعی را جعل یا جایگزین نمی‌کند.

## راه‌اندازی پنل

1. پوشه `admin/` را روی هاست PHP قرار دهید، ترجیحاً روی `admin.subkazani.ir`.
2. `admin/config.example.php` را به `admin/config.php` کپی کنید.
3. مقدارهای GitHub owner/repository/branch/token و رمز مدیر را تنظیم کنید.
4. برای GitHub token فقط دسترسی لازم برای Contents را بدهید؛ توکن را هرگز داخل `site/` قرار ندهید.
5. مسیر GitHub Pages را همچنان به Repository اصلی وصل نگه دارید.

## فرآیند افزودن آهنگ

پنل فایل MP3 را با GitHub API در Repository قرار می‌دهد و سپس `data/content.json` را به‌روزرسانی می‌کند. سایت استاتیک بعد از انتشار GitHub Pages داده جدید را می‌خواند.

## قبل از انتشار نهایی

- یک backup از Repository بگیرید.
- توکن GitHub را داخل Git commit نکنید.
- رمز پیش‌فرض را عوض کنید.
- ابتدا در یک branch آزمایشی تست کنید.
