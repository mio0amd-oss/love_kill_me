<?php
return [
    // GitHub repository that hosts subkazani.ir
    'github_owner' => 'mio0amd-oss',
    'github_repo' => 'love_kill_me',
    'github_branch' => 'main',
    'github_token' => 'PUT_GITHUB_TOKEN_HERE',

    // Set a strong password hash with password_hash('YOUR_PASSWORD', PASSWORD_DEFAULT)
    'admin_password_hash' => 'PUT_PASSWORD_HASH_HERE',

    'session_name' => 'subkazani_admin',
    'content_path' => 'data/content.json',
    'music_dir' => 'music'
];
