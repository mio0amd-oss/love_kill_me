<?php
session_start();
$config = require __DIR__ . '/config.php';
if (!hash_equals((string)($config['session_name'] ?? 'subkazani_admin'), session_name())) {
    session_name((string)($config['session_name'] ?? 'subkazani_admin'));
}
function cfg(string $key) { global $config; return $config[$key] ?? null; }
function logged_in(): bool { return !empty($_SESSION['admin_ok']); }
function redirect_self(): never { header('Location: index.php'); exit; }
if (isset($_GET['logout'])) { $_SESSION = []; session_destroy(); redirect_self(); }
if (!logged_in()) {
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $pass = (string)($_POST['password'] ?? '');
        if (password_verify($pass, (string)cfg('admin_password_hash'))) {
            session_regenerate_id(true); $_SESSION['admin_ok'] = true; redirect_self();
        }
        $error = 'رمز عبور نادرست است.';
    }
    ?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود | subkazani</title><style>body{margin:0;background:#090202;color:#fff;font-family:Arial,sans-serif;min-height:100vh;display:grid;place-items:center}.box{width:min(380px,90vw);background:#170606;border:1px solid #4a1717;border-radius:16px;padding:28px;box-shadow:0 20px 60px #000}h1{font-size:22px;text-align:center}input,button{width:100%;padding:13px;margin-top:12px;border-radius:9px;border:1px solid #542020;background:#0b0202;color:#fff;box-sizing:border-box}button{background:#8e1515;cursor:pointer}.err{color:#ff9b9b;text-align:center;margin-top:12px}</style></head><body><form class="box" method="post"><h1>پنل مدیریت subkazani</h1><input name="password" type="password" placeholder="رمز عبور" autocomplete="current-password" required><button>ورود</button><?php if($error): ?><div class="err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif; ?></form></body></html><?php exit; }

function gh_request(string $method, string $path, ?array $body=null): array {
    $token=(string)cfg('github_token');
    if ($token === '' || str_contains($token,'PUT_GITHUB')) throw new RuntimeException('GitHub token در config.php تنظیم نشده است.');
    $url='https://api.github.com/repos/'.rawurlencode(cfg('github_owner')).'/'.rawurlencode(cfg('github_repo')).'/'.$path;
    $ch=curl_init($url);
    $headers=['Accept: application/vnd.github+json','Authorization: Bearer '.$token,'X-GitHub-Api-Version: 2022-11-28','User-Agent: subkazani-cms'];
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>30]);
    if($body!==null){$headers[]='Content-Type: application/json';curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));}
    $raw=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
    if($raw===false) throw new RuntimeException('GitHub connection failed: '.$err);
    $data=json_decode($raw,true);
    if($code<200||$code>=300) throw new RuntimeException('GitHub API '.$code.': '.($data['message']??$raw));
    return $data;
}
function get_file(string $path): array {
    return gh_request('GET','contents/'.str_replace('%2F','/',rawurlencode($path)).'?ref='.rawurlencode(cfg('github_branch')));
}
function get_content(): array {
    $f=get_file(cfg('content_path'));
    $decoded=base64_decode(str_replace("\n",'',(string)$f['content']),true);
    $data=json_decode($decoded?:'',true);
    if(!is_array($data)) throw new RuntimeException('content.json معتبر نیست.');
    return [$data,$f['sha']];
}
function put_file(string $path,string $content,string $message,?string $sha=null): array {
    $body=['message'=>$message,'content'=>base64_encode($content),'branch'=>cfg('github_branch')];
    if($sha)$body['sha']=$sha;
    return gh_request('PUT','contents/'.str_replace('%2F','/',rawurlencode($path)),$body);
}
function delete_file(string $path,string $message): void {
    $f=get_file($path);
    gh_request('DELETE','contents/'.str_replace('%2F','/',rawurlencode($path)),['message'=>$message,'sha'=>$f['sha'],'branch'=>cfg('github_branch')]);
}
function clean_id(string $v): string { return preg_replace('/[^a-zA-Z0-9_-]+/','-',trim($v)) ?: 'item-'.time(); }
function save_content(array $data,string $sha): void {
    $data['version']=1;
    $json=json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
    put_file(cfg('content_path'),$json,'CMS: update content',$sha);
}

$msg=''; $error='';
try {
    if($_SERVER['REQUEST_METHOD']==='POST') {
        $action=(string)($_POST['action']??'');
        [$data,$sha]=get_content();
        $data['music']=array_values($data['music']??[]); $data['texts']=array_values($data['texts']??[]);
        if($action==='save_music'){
            $id=clean_id((string)($_POST['id']??''));
            $item=['id'=>$id,'fa'=>trim((string)($_POST['fa']??'')),'en'=>trim((string)($_POST['en']??'')),'position'=>max(1,(int)($_POST['position']??1)),'side'=>($_POST['side']??'left')==='right'?'right':'left','active'=>isset($_POST['active'])];
            if($item['fa']==='') throw new RuntimeException('متن فارسی آهنگ الزامی است.');
            $existingIndex=null; foreach($data['music'] as $i=>$x) if(($x['id']??'')===$id){$existingIndex=$i;break;}
            if(!empty($_FILES['audio']['tmp_name']) && is_uploaded_file($_FILES['audio']['tmp_name'])){
                $ext=strtolower(pathinfo($_FILES['audio']['name'],PATHINFO_EXTENSION));
                if($ext!=='mp3') throw new RuntimeException('فعلاً فقط MP3 مجاز است.');
                if((int)$_FILES['audio']['size']>30*1024*1024) throw new RuntimeException('حداکثر حجم فایل MP3 برابر 30MB است.');
                $safe=clean_id(pathinfo($_FILES['audio']['name'],PATHINFO_FILENAME)).'-'.substr(hash('sha256',random_bytes(16)),0,8).'.mp3';
                $path=trim(cfg('music_dir'),'/').'/'.$safe;
                $bytes=file_get_contents($_FILES['audio']['tmp_name']);
                put_file($path,$bytes,'CMS: add music '.$safe,null);
                $item['file']=$path;
            } elseif($existingIndex!==null) { $item['file']=$data['music'][$existingIndex]['file']; }
            else throw new RuntimeException('برای آهنگ جدید باید فایل MP3 انتخاب شود.');
            if($existingIndex===null)$data['music'][]=$item; else $data['music'][$existingIndex]=$item;
            save_content($data,$sha); $msg='آهنگ ذخیره شد.';
        } elseif($action==='save_text'){
            $id=clean_id((string)($_POST['id']??''));
            $item=['id'=>$id,'fa'=>trim((string)($_POST['fa']??'')),'en'=>trim((string)($_POST['en']??'')),'position'=>max(1,(int)($_POST['position']??1)),'active'=>isset($_POST['active'])];
            if($item['fa']==='') throw new RuntimeException('متن فارسی الزامی است.');
            $found=false; foreach($data['texts'] as $i=>$x) if(($x['id']??'')===$id){$data['texts'][$i]=$item;$found=true;break;}
            if(!$found)$data['texts'][]=$item; save_content($data,$sha); $msg='متن ذخیره شد.';
        } elseif($action==='delete_music' || $action==='delete_text'){
            $key=$action==='delete_music'?'music':'texts'; $id=(string)($_POST['id']??'');
            $kept=[]; $deleted=null; foreach($data[$key] as $x){if(($x['id']??'')===$id)$deleted=$x;else $kept[]=$x;}
            if(!$deleted) throw new RuntimeException('مورد پیدا نشد.');
            $data[$key]=$kept; save_content($data,$sha);
            if($key==='music' && !empty($deleted['file']) && !str_starts_with($deleted['file'],'http')) { try { delete_file($deleted['file'],'CMS: delete music'); } catch(Throwable $ignore) {} }
            $msg='حذف شد.';
        }
    }
    [$data,$sha]=get_content();
} catch(Throwable $e) { $error=$e->getMessage(); if(!isset($data))$data=['music'=>[],'texts'=>[]]; }
$music=$data['music']??[]; $texts=$data['texts']??[];
usort($music,fn($a,$b)=>(($a['position']??0)<=>($b['position']??0))); usort($texts,fn($a,$b)=>(($a['position']??0)<=>($b['position']??0)));
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>مدیریت subkazani</title><style>
*{box-sizing:border-box}body{margin:0;background:#090202;color:#f8eeee;font-family:Tahoma,Arial,sans-serif}.wrap{max-width:1050px;margin:auto;padding:24px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px}.brand{font-size:22px;font-weight:700}.link,button{border:1px solid #5a2020;background:#190606;color:#fff;padding:10px 14px;border-radius:9px;text-decoration:none;cursor:pointer}.primary{background:#8e1515;border-color:#a92a2a}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.card{background:#130505;border:1px solid #411414;border-radius:15px;padding:18px;box-shadow:0 12px 40px #0005}.full{grid-column:1/-1}h2{margin-top:0;font-size:18px}label{display:block;margin:10px 0 6px;color:#dcbcbc;font-size:13px}input,textarea,select{width:100%;background:#080202;color:#fff;border:1px solid #4b1b1b;border-radius:8px;padding:10px}textarea{min-height:90px;resize:vertical}.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}.item{border-top:1px solid #351010;padding:14px 0}.item:first-child{border-top:0}.meta{font-size:12px;color:#a98f8f;margin:5px 0 10px}.actions{display:flex;gap:8px;flex-wrap:wrap}.danger{background:#2a0808;border-color:#7c2222}.notice{padding:12px;border-radius:10px;margin-bottom:16px}.ok{background:#0c2a17}.err{background:#350b0b;color:#ffc1c1}.muted{color:#9e8787;font-size:12px}@media(max-width:760px){.grid{grid-template-columns:1fr}.full{grid-column:auto}.row{grid-template-columns:1fr}.top{align-items:flex-start;flex-direction:column}}
</style></head><body><div class="wrap"><div class="top"><div class="brand">ꕥ subkazani — مدیریت محتوا</div><div><a class="link" href="https://subkazani.ir" target="_blank">مشاهده سایت</a> <a class="link" href="?logout=1">خروج</a></div></div>
<?php if($msg): ?><div class="notice ok"><?=h($msg)?></div><?php endif; ?><?php if($error): ?><div class="notice err"><?=h($error)?></div><?php endif; ?>
<div class="grid">
<section class="card"><h2>🎵 افزودن / ویرایش آهنگ</h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="action" value="save_music"><label>ID</label><input name="id" placeholder="مثلاً music-005" required><label>متن فارسی</label><textarea name="fa" required></textarea><label>متن انگلیسی</label><textarea name="en"></textarea><div class="row"><div><label>ترتیب</label><input type="number" name="position" min="1" value="1"></div><div><label>جهت متن</label><select name="side"><option value="left">سمت چپ</option><option value="right">سمت راست</option></select></div></div><label>فایل MP3 (برای آهنگ جدید الزامی)</label><input type="file" name="audio" accept="audio/mpeg,.mp3"><label><input type="checkbox" name="active" checked> نمایش در سایت</label><button class="primary" type="submit">ذخیره آهنگ</button></form><p class="muted">برای ویرایش یک آهنگ، همان ID را وارد کنید. اگر فایل جدید انتخاب نکنید، فایل قبلی حفظ می‌شود.</p></section>
<section class="card"><h2>📝 افزودن / ویرایش متن</h2><form method="post"><input type="hidden" name="action" value="save_text"><label>ID</label><input name="id" placeholder="مثلاً text-003" required><label>متن فارسی</label><textarea name="fa" required></textarea><label>متن انگلیسی (اختیاری)</label><textarea name="en"></textarea><label>ترتیب</label><input type="number" name="position" min="1" value="1"><label><input type="checkbox" name="active" checked> نمایش در سایت</label><button class="primary" type="submit">ذخیره متن</button></form></section>
<section class="card full"><h2>🎵 آهنگ‌های فعلی (<?=count($music)?>)</h2><?php foreach($music as $x): ?><div class="item"><strong><?=h($x['fa']??'')?></strong><div class="meta">ID: <?=h($x['id']??'')?> · ترتیب: <?=h($x['position']??'')?> · <?=($x['active']??false)?'فعال':'مخفی'?> · فایل: <?=h($x['file']??'')?></div><div class="actions"><form method="post" onsubmit="return confirm('این آهنگ حذف شود؟')"><input type="hidden" name="action" value="delete_music"><input type="hidden" name="id" value="<?=h($x['id']??'')?>"><button class="danger">حذف واقعی</button></form></div></div><?php endforeach; if(!$music): ?><p class="muted">آهنگی وجود ندارد.</p><?php endif; ?></section>
<section class="card full"><h2>📝 متن‌های فعلی (<?=count($texts)?>)</h2><?php foreach($texts as $x): ?><div class="item"><strong><?=h(mb_substr($x['fa']??'',0,180))?></strong><div class="meta">ID: <?=h($x['id']??'')?> · ترتیب: <?=h($x['position']??'')?> · <?=($x['active']??false)?'فعال':'مخفی'?></div><div class="actions"><form method="post" onsubmit="return confirm('این متن حذف شود؟')"><input type="hidden" name="action" value="delete_text"><input type="hidden" name="id" value="<?=h($x['id']??'')?>"><button class="danger">حذف</button></form></div></div><?php endforeach; if(!$texts): ?><p class="muted">متنی وجود ندارد.</p><?php endif; ?></section>
</div></div></body></html>
